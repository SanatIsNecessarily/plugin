package io.geekidea.springboot.assembly;

/**
 * 测试服务接口
 * @author geekidea
 * @date 2018/11/20
 */
public interface HelloService {

    /**
     * 测试方法
     * @param name
     * @return
     */
    String hello(String name);

}
